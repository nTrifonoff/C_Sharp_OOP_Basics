﻿namespace FoodShortage.Interfaces
{
    public interface IAge
    {
        int Age { get; }
    }
}
