﻿using System;
namespace FoodShortage.Interfaces
{
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}
